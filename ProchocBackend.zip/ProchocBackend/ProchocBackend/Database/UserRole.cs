﻿namespace ProchocBackend.Database
{
    public enum UserRole
    {
        Admin, Customer
    }
}
